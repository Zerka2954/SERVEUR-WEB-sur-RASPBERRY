#!/bin/sh
cd /var/www/html/SITE
php artisan serve --host=192.168.10.115 --port=2223


